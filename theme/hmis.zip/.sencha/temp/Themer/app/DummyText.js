/**
 * Created by mbrocato on 1/22/16.
 */
Ext.define('Viewer.DummyText', {
    singleton: true,

    /**
     * @property {String}
     */
    mediumText: 'There is a theory which states that if ever anyone discovers exactly what the Universe is for and why it is here, it will instantly disappear and be replaced by something even more bizarre and inexplicable. There is another theory which states that this has already happened.',
    shortText : 'The ships hung in the sky in much the same way that bricks don’t.'
});