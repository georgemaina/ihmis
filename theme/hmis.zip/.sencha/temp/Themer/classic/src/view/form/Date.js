/**
 * Calendar control.
 */
Ext.define('Viewer.view.form.Date', {
    extend: 'Ext.picker.Date',
    xtype: 'c-preview-form-date'
});