Ext.define('Viewer.view.grid.AdvancedGroupedGrid', {
    extend : 'Ext.grid.Panel',
    xtype: 'c-preview-advanced-grouped-grid',
    store: Ext.create('Viewer.store.GroupGridStore'),

    width: 600,
    height: 400,
    // Need a minHeight. Neptune resizable framed panels are overflow:visible so as to
    // enable resizing handles to be embedded in the border lines.
    minHeight: 200,
    resizable: true,

    controller: {
        expandAll: function() {
            this.getView().expandAll();
        },
    
        collapseAll: function() {
            this.getView().collapseAll();
        },

        changeGroupSummaryPosition: function(item) {
            this.getView().setGroupSummaryPosition(item.text);
        },

        changeSummaryPosition: function(item) {
            this.getView().setSummaryPosition(item.text);
        }
    },

    dockedItems: [{
        xtype: 'toolbar',
        items: [
            '->',
            {
                xtype: 'button',
                cls: 'dock-tab-btn',
                text: 'Group summary position',
                menu: [{
                    text: 'top',
                    handler: 'changeGroupSummaryPosition'
                }, {
                    text: 'bottom',
                    handler: 'changeGroupSummaryPosition'
                }, {
                    text: 'hidden',
                    handler: 'changeGroupSummaryPosition'
                }]
            }, 
            {
                xtype: 'button',
                cls: 'dock-tab-btn',
                text: 'Summary position',
                menu: [{
                    text: 'docked',
                    handler: 'changeSummaryPosition'
                }, {
                    text: 'top',
                    handler: 'changeSummaryPosition'
                }, {
                    text: 'bottom',
                    handler: 'changeSummaryPosition'
                }, {
                    text: 'hidden',
                    handler: 'changeSummaryPosition'
                }]
            }, 
            {
                xtype: 'button',
                cls: 'dock-tab-btn',
                text: 'Visibility',
                menu: [{
                    text: 'Expand all',
                    handler: 'expandAll'
                }, {
                    text: 'Collapse all',
                    handler: 'collapseAll'
                }]
            }
        ]
    }],

    columns: [
        {
            text: 'Name',
            flex: 1,
            dataIndex: 'name',
            groupable: true
        },
        {
            text: 'Cuisine',
            flex: 1,
            dataIndex: 'cuisine',
            groupable: true
        }
    ]

}, function (cls) {
    if (Ext.getVersion().isGreaterThanOrEqual(7.4)) {
        // these are new ext 7.4 features so we load them here
        // so that Themer can still work for older versions of the SDK
        Ext.require([
            'Ext.grid.feature' + '.AdvancedGroupingSummary',
            'Ext.grid.plugin' + '.GroupingPanel',
            'Ext.grid.plugin' + '.Summaries'
        ], function () {
            cls.prototype.features = [{
                ftype: 'advancedgroupingsummary',
                startCollapsed: true
            }];
            cls.prototype.plugins = {
                groupingpanel: true,
                gridsummaries: true
            };
        });
    }
});