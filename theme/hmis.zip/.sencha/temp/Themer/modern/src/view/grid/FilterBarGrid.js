Ext.define('Viewer.view.grid.FilterBarGrid', {
    extend: 'Ext.grid.Grid',
    xtype: 'c-preview-filterbar-grid',
    store: Ext.create('Viewer.store.GroupGridStore'),

    columns: [
        {
            text: 'Name',
            flex: 1,
            dataIndex: 'name',
            filterType: {
                type: 'string',
                operator: 'like'
            }
        },
        {
            text: 'Cuisine',
            flex: 1,
            dataIndex: 'cuisine',
            filterType: 'list'
        }
    ],
    
    initialize: function () {
        if (Ext.getVersion().isGreaterThanOrEqual(7.4)) {
            this.addPlugin('gridfilterbar');
        }
        this.callParent(arguments);
    }
        
}, function (cls) {
        if (Ext.getVersion().isGreaterThanOrEqual(7.4)) {
            // these are new ext 7.4 features so we load them here
            // so that Themer can still work for older versions of the SDK
            Ext.require([
                'Ext.grid.plugin' + '.filterbar.FilterBar' // break up the class name so Cmd will not try to resolve it and include in the build
            ]);
        }
});