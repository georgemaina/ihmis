Ext.namespace('Ext.theme.is')['hmis'] = true;
Ext.theme.name = 'hmis';