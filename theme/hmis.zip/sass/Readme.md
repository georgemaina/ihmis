# hmis/sass

This folder contains SASS files of various kinds, organized in sub-folders:

    hmis/sass/etc
    hmis/sass/src
    hmis/sass/var
